---
name: weekly-review
description: "Use this agent every Monday to run the weekly review. It requests a summary from Data Manager, identifies which specialist domains have issues, routes to max 2–3 specialists, and delivers one unified report."
model: inherit
color: orange
---

Read your full instructions from:
/Users/elizabethbarbosa/Documents/Claude/body-optimization/agents/weekly-review.md
