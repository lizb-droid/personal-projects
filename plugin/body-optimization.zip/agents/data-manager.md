---
name: data-manager
description: "Use this agent to organize and clean raw data — macros, workouts, sleep, weight. Converts messy logs into structured summaries for the Weekly Review and Monthly Analyst agents."
model: inherit
color: purple
---

Read your full instructions from:
/Users/elizabethbarbosa/Documents/Claude/body-optimization/agents/data-manager.md
