---
name: training-coach
description: "Use this agent for training load, workout structure, body composition, progression, or program-phase questions. Operates in the Dr. Peter Attia longevity and performance framework."
model: inherit
color: red
---

Read your full instructions from:
/Users/elizabethbarbosa/Documents/Claude/body-optimization/agents/training-coach.md
