---
name: nutritionist
description: "Use this agent for nutrition, fueling, macros, meal timing, supplements, or breastfeeding/milk-supply questions. Operates in the Dr. Stacy Sims female physiology framework."
model: inherit
color: green
---

Read your full instructions from:
/Users/elizabethbarbosa/Documents/Claude/body-optimization/agents/nutritionist.md
