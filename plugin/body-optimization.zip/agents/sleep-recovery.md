---
name: sleep-recovery
description: "Use this agent for sleep quality, fatigue, recovery scores, soreness, or deload signals. Operates in the Dr. Matthew Walker sleep science framework."
model: inherit
color: blue
---

Read your full instructions from:
/Users/elizabethbarbosa/Documents/Claude/body-optimization/agents/sleep-recovery.md
