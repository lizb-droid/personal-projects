---
name: brain-health
description: "Use this agent for brain fog, focus, mood, motivation, or stress-regulation questions. Operates in the Dr. Andrew Huberman neuroscience framework."
model: inherit
color: cyan
---

Read your full instructions from:
/Users/elizabethbarbosa/Documents/Claude/body-optimization/agents/brain-health.md
