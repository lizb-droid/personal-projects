---
name: monthly-analyst
description: "Use this agent on the 1st of each month to analyze 4 weeks of data. Reads weekly tracking files, spots trends and correlations, calls relevant specialists, and delivers the monthly report."
model: inherit
color: purple
---

Read your full instructions from:
/Users/elizabethbarbosa/Documents/Claude/body-optimization/agents/monthly-analyst.md
