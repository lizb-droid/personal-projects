# Cowork Setup — Body Optimization

How to install, use, and maintain the body-optimization agent team in Claude Cowork (desktop).

---

## 1. Install the Plugin (one time)

1. Find **`body-optimization.plugin`** — copies live in two places:
   - `Desktop/body-optimization.plugin` (also `body-optimization.zip` if the `.plugin` extension isn't accepted)
   - `Documents/Claude/personal-projects/body-optimization/plugin/`
2. **Drag the file into any Cowork chat window**
3. Accept the install prompt
4. Type `/` — you should see 5 new skills: `daily-log`, `weekly-checkin`, `app-session`, `program-review`, `insights`

**Only connector needed:** GitHub (already connected as `lizb-droid`).

**If you ever see two versions installed:** remove the older one in your plugins list. Only the latest build has the correct file paths.

---

## 2. The Skills

| Skill | When | What happens |
|---|---|---|
| `/weekly-checkin` | Every Monday | Paste your week's data. All 8 specialists silently scan it — only the ones with something real to say appear. You get ONE report: data summary, what's working, attention items, one adjustment. |
| `/app-session` | Whenever you want to build | Designer (Nike Digital) + Developer join. Designer brings 2–3 options, you pick, Developer builds and pushes to GitHub. |
| `/program-review` | Before phase changes, or anytime | Sims + Attia review a workout, a phase, or the whole 17-week program. Output: KEEP / CHANGE / ADD / REMOVE. |
| `/insights` | Anytime you have data | Paste logs, app exports (JSON), or race results. Data Analyst finds the trend, the right specialist interprets it. |
| `/daily-log` | Daily (optional on desktop) | Quick log routed to the right specialist. Your phone Claude.ai Project covers this too — use whichever is closer. |

---

## 3. The Team Behind the Skills

9 agents, coordinated by the Orchestrator:

- **Orchestrator** — routes daily questions to 1–3 specialists max; runs the full-team scan only on Mondays
- **Dr. Stacy Sims** — nutrition, fueling, cycle-phase adjustments, milk supply
- **Dr. Matthew Walker** — sleep, recovery
- **Dr. Peter Attia** — training load, progression, body composition
- **Dr. Andrew Huberman** — focus, mood, brain health
- **James Clear** — habits and consistency (proactive: he scans your Monday data without being asked)
- **Data Analyst** — trends, 4-week rules, red flags
- **Designer** — Nike Digital UI/UX; proposes options, you have final vote
- **Developer** — builds what's decided; surfaces tradeoffs, doesn't decide them

---

## 4. How Agents Stay Up to Date

All agents read their instructions and your data from:

```
Documents/Claude/personal-projects/body-optimization/
├── agents/      ← agent instructions (source of truth)
├── profile/     ← your athlete profile
├── program/     ← 17-week program + revisions
├── design/      ← app design spec
├── app/         ← liz-program.jsx + future app code
└── tracking/    ← log templates
```

**Edit any of these files (or ask any agent to) and every agent picks up the change immediately.** No plugin rebuild needed for content changes.

The same files are synced to GitHub: [`lizb-droid/personal-projects`](https://github.com/lizb-droid/personal-projects) → `body-optimization/`.

---

## 5. When the Plugin DOES Need a Rebuild

Only if one of these changes:
- The **folder moves** (file paths inside the plugin break)
- You want to **add/remove a skill or agent**
- The **plugin name** changes

To rebuild, just ask Claude in any Cowork session:
> "Rebuild the body-optimization plugin — the source is in /tmp/body-optimization-plugin (or recreate from the repo files) and the project folder is at Documents/Claude/personal-projects/body-optimization"

Then remove the old plugin from Cowork and drag in the new file.

---

## 6. Your Weekly Rhythm

| When | Where | What |
|---|---|---|
| Every morning | Phone — Claude.ai Project | Quick log: macros, session, recovery, milk supply |
| Wednesday + Saturday | Phone | Race/run notes |
| **Monday** | **Cowork — `/weekly-checkin`** | Paste the week, get the full-team report |
| Whenever | Cowork — `/app-session` | Build the app |
| Phase transitions (Wks 4/5, 9/10, 12/13) | Cowork — `/program-review` | Adjust the program before the next block |

---

## 7. Data Safety

- App data lives in **localStorage on your iPhone** (Safari)
- **Daily habit:** tap Export in the app → paste into Notes
- To restore (new phone, cleared Safari): paste the JSON back via Import
- Weekly check-in data: paste it into `/weekly-checkin` — it lives in the conversation and can be saved to the repo on request
